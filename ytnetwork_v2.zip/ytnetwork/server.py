import glob, hashlib, json, os, re, shutil, tempfile, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from flask import Flask, Response, abort, jsonify, redirect, request, send_file, send_from_directory
from yt_dlp import YoutubeDL

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(HERE, "static")
app = Flask(__name__, static_folder=STATIC, static_url_path="/static")
S = requests.Session()
S.mount("https://", requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=60))
lock, locks, cache = threading.Lock(), {}, {}
pool = ThreadPoolExecutor(12)

JSR = {r: {} for r in ("deno", "node", "bun") if shutil.which(r)}
BASE = {"quiet": True, "no_warnings": True, "noplaylist": True, "socket_timeout": 15}
if JSR:
    BASE["js_runtimes"] = JSR
    BASE["remote_components"] = ["ejs:github"]

FMT = "best[ext=mp4][acodec!=none][vcodec!=none]/best[acodec!=none][vcodec!=none]/best"
AFMT = "bestaudio[ext=m4a]/bestaudio/best"

DEFAULTS = {
    "pt": ["em alta hoje", "melhores momentos", "música brasileira", "tecnologia"],
    "en": ["trending today", "best moments", "music", "technology"],
    "es": ["tendencias hoy", "mejores momentos", "música latina", "tecnología"],
    "fr": ["tendances aujourd'hui", "meilleurs moments", "musique française", "technologie"],
    "de": ["trends heute", "beste momente", "deutsche musik", "technik"],
    "it": ["tendenze oggi", "momenti migliori", "musica italiana", "tecnologia"],
    "ja": ["人気 急上昇", "音楽", "ゲーム実況", "ニュース"],
    "ko": ["인기 급상승", "음악", "게임", "뉴스"],
    "ru": ["тренды сегодня", "музыка", "игры", "новости"],
    "hi": ["ट्रेंडिंग", "गाने", "मनोरंजन", "समाचार"],
    "ar": ["الأكثر رواجا", "موسيقى", "ألعاب", "أخبار"],
}
STOP = {
    "pt": "o a os as um uma de do da dos das em no na nos nas que não com para por mais como mas foi são ao você vocês isso esse essa muito também até quando eu meu minha".split(),
    "en": "the and of to in is you that it for on with this are was be as at your how what from my we they not but have".split(),
    "es": "el la los las un una de del en que y con para por más como pero fue son al tú usted esto este esta muy también hasta cuando yo mi mis".split(),
    "fr": "le la les un une des du de en et que qui pour pas avec sur dans est sont au aux ce cette très aussi mais je mon ma".split(),
    "de": "der die das und ein eine ist nicht mit für auf von zu den dem des sich auch wie aber ich du wir sie es im".split(),
    "it": "il lo la le gli un una di del della in che e per non con su come più ma è sono al questo questa molto anche io mio".split(),
}
STOP = {k: set(v) for k, v in STOP.items()}
SCRIPTS = [(r"[\u3040-\u30ff]", "ja"), (r"[\uac00-\ud7af]", "ko"), (r"[\u0400-\u04ff]", "ru"),
           (r"[\u0900-\u097f]", "hi"), (r"[\u0600-\u06ff]", "ar")]


def lang_of(t):
    t = t or ""
    for rg, l in SCRIPTS:
        if re.search(rg, t):
            return l
    if re.search(r"[ãõ]", t.lower()):
        return "pt"
    if "ñ" in t.lower():
        return "es"
    w = set(re.findall(r"[a-zà-ÿ']+", t.lower()))
    best, top, tie = None, 0, False
    for l, s in STOP.items():
        n = len(w & s)
        if n > top:
            best, top, tie = l, n, False
        elif n == top and n:
            tie = True
    return None if tie else best


def _fmt(f):
    return {"url": f["url"], "h": f.get("http_headers") or {}, "height": f.get("height") or 0,
            "ext": f.get("ext"), "vc": f.get("vcodec") or "none", "ac": f.get("acodec") or "none",
            "tbr": f.get("tbr") or f.get("vbr") or f.get("abr") or 0, "size": f.get("filesize") or f.get("filesize_approx"),
            "proto": f.get("protocol", "")}


def resolve(vid, audio=False):
    # one yt-dlp run per video (was: one per kind) -> every format is kept in the cache
    c = cache.get(vid)
    if c and c["exp"] > time.time():
        return c
    with lock:
        l = locks.setdefault(vid, threading.Lock())
    with l:
        c = cache.get(vid)
        if c and c["exp"] > time.time():
            return c
        with YoutubeDL({**BASE, "skip_download": True, "check_formats": False}) as y:
            info = y.extract_info("https://youtu.be/" + vid, download=False)
        fm = [_fmt(f) for f in (info.get("formats") or []) if f.get("url") and str(f.get("protocol", "")).startswith("http")]
        if not fm and info.get("url"):
            fm = [_fmt(info)]
        c = {"fm": fm, "exp": time.time() + 3 * 3600,
             "title": info.get("title", ""), "channel": info.get("uploader", ""),
             "cid": info.get("channel_id"), "views": info.get("view_count"),
             "likes": info.get("like_count"), "date": info.get("upload_date"),
             "desc": (info.get("description") or "")[:5000],
             "tags": [t for t in (info.get("tags") or []) if " " not in t][:3],
             "subs": info.get("channel_follower_count"), "dur": info.get("duration"),
             "lang": lang_of(info.get("title", "")),
             "chapters": [{"start": x.get("start_time", 0), "title": x.get("title", "")} for x in (info.get("chapters") or [])],
             "comment_count": info.get("comment_count"), "verified": bool(info.get("channel_is_verified"))}
        c["muxh"] = max([f["height"] for f in fm if f["vc"] != "none" and f["ac"] != "none"] or [0])
        c["q"] = sorted({f["height"] for f in fm if f["vc"] != "none" and f["ac"] == "none" and f["height"] and f["ext"] == "mp4"}
                        | ({c["muxh"]} if c["muxh"] else set()))
        cache[vid] = c
        return c


def pick(c, kind, h=0):
    fm = c["fm"]
    if kind == "a":
        xs = [f for f in fm if f["ac"] != "none" and f["vc"] == "none"]
        xs.sort(key=lambda f: (f["ext"] == "m4a", f["tbr"]), reverse=True)
        return xs[0] if xs else None
    if kind == "v":
        xs = [f for f in fm if f["vc"] != "none" and f["ac"] == "none" and f["ext"] == "mp4" and f["height"] and (not h or f["height"] <= h)]
        xs.sort(key=lambda f: (f["height"], f["vc"].startswith("avc1"), f["tbr"]), reverse=True)
        return xs[0] if xs else None
    xs = [f for f in fm if f["vc"] != "none" and f["ac"] != "none"]
    xs.sort(key=lambda f: (f["ext"] == "mp4", f["height"], f["tbr"]), reverse=True)
    return xs[0] if xs else (fm[0] if fm else None)


sc = {}


def ysearch(q, n):
    k = (q, n)
    c = sc.get(k)
    if c and c[0] > time.time():
        return c[1]
    with YoutubeDL({**BASE, "extract_flat": True, "skip_download": True}) as y:
        r = y.extract_info(f"ytsearch{n}:{q}", download=False)
    items = [{"id": e["id"], "title": e.get("title"), "channel": e.get("channel") or e.get("uploader"),
              "cid": e.get("channel_id"), "dur": e.get("duration"), "views": e.get("view_count"),
              "lang": lang_of(e.get("title")),
              "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg"}
             for e in r.get("entries", []) if e and len(e.get("id", "")) == 11]
    sc[k] = (time.time() + 900, items)
    return items


def allowed(i, L, mix):
    if L == "a" or i["lang"] in (None, L):
        return True
    return mix > 0 and int(hashlib.md5(i["id"].encode()).hexdigest()[:2], 16) % 100 < mix * 100


@app.route("/api/feed")
def api_feed():
    L = request.args.get("l", "en")
    qs = [x for x in request.args.get("q", "").split("|") if x.strip()][:4]
    if not qs:
        qs = DEFAULTS.get(L, DEFAULTS["en"])[:2]
    p = max(1, int(request.args.get("page", 1)))
    short = request.args.get("short") == "1"
    mix = min(0.5, float(request.args.get("mix", 0) or 0))
    per = 12 if len(qs) > 1 else 24

    def job(q):
        try:
            if short:
                items = ysearch(q + " #shorts", 30 * p)[30 * (p - 1):]
                items = [i for i in items if i["dur"] and i["dur"] <= 61]
            else:
                items = ysearch(q, per * p)[per * (p - 1):]
            return [i for i in items if allowed(i, L, mix)]
        except Exception:
            return []

    futs = [pool.submit(job, q) for q in qs]

    def gen():
        seen = set()
        for f in as_completed(futs):
            for i in f.result():
                if i["id"] not in seen:
                    seen.add(i["id"])
                    yield json.dumps(i) + "\n"

    return Response(gen(), mimetype="application/x-ndjson",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-store"})


@app.route("/api/info/<vid>")
def api_info(vid):
    try:
        c = resolve(vid)
    except Exception as e:
        return str(e), 502
    return jsonify({k: c[k] for k in ("title", "channel", "cid", "views", "likes", "date", "desc",
                                      "tags", "subs", "dur", "lang", "chapters", "comment_count", "verified", "q", "muxh")})


cc = {}


@app.route("/api/comments/<vid>")
def api_comments(vid):
    sort = "new" if request.args.get("sort") == "new" else "top"
    try:
        n = min(100, max(10, int(request.args.get("n", 20))))
    except ValueError:
        n = 20
    k = (vid, sort, n)
    c = cc.get(k)
    if c and c[0] > time.time():
        return jsonify(c[1])
    out = {"count": None, "items": []}
    ttl = 60
    try:
        opts = {**BASE, "skip_download": True, "getcomments": True,
                "extractor_args": {"youtube": {"max_comments": [str(n * 3), str(n), str(n * 2), "3", "1"],
                                               "comment_sort": [sort]}}}
        with YoutubeDL(opts) as y:
            info = y.extract_info("https://youtu.be/" + vid, download=False)
        rows = info.get("comments") or []
        by = {}
        for x in rows:
            if x.get("parent") in (None, "root"):
                by[x["id"]] = {"id": x["id"], "author": x.get("author"), "text": x.get("text"),
                               "likes": x.get("like_count"), "ts": x.get("timestamp"),
                               "thumb": x.get("author_thumbnail"), "pinned": bool(x.get("is_pinned")),
                               "creator": bool(x.get("author_is_uploader")), "heart": bool(x.get("is_favorited")),
                               "replies": []}
        for x in rows:
            p = by.get(x.get("parent"))
            if p is not None:
                p["replies"].append({"id": x["id"], "author": x.get("author"), "text": x.get("text"),
                                     "likes": x.get("like_count"), "ts": x.get("timestamp"),
                                     "thumb": x.get("author_thumbnail"), "creator": bool(x.get("author_is_uploader")),
                                     "heart": bool(x.get("is_favorited")), "pinned": False})
        out = {"count": info.get("comment_count"), "items": list(by.values())}
        ttl = 3600 if out["items"] else 60
    except Exception:
        pass
    cc[k] = (time.time() + ttl, out)
    return jsonify(out)


AV_FILE = os.path.join(HERE, "avatars.json")
try:
    av = json.load(open(AV_FILE))
except Exception:
    av = {}
av_sem = threading.Semaphore(8)


def fetch_avatar(cid):
    try:
        with YoutubeDL({**BASE, "extract_flat": True, "playlistend": 1, "skip_download": True}) as y:
            info = y.extract_info(f"https://www.youtube.com/channel/{cid}", download=False)
        th = info.get("thumbnails") or []
        pick = next((t for t in th if "avatar" in str(t.get("id", ""))), None) or \
            next((t for t in th if t.get("width") and t.get("width") == t.get("height")), None)
        url = pick["url"] if pick else None
        if url and ("ggpht" in url or "googleusercontent" in url):
            url = re.sub(r"=s\d+.*$", "=s96-c", url)
        a = {"url": url}
    except Exception:
        a = {"url": None, "retry": time.time() + 600}
    av[cid] = a
    try:
        json.dump(av, open(AV_FILE, "w"))
    except Exception:
        pass
    return a


@app.route("/avatar/<cid>")
def avatar(cid):
    if not re.fullmatch(r"[\w-]{10,40}", cid):
        abort(404)
    a = av.get(cid)
    if not a or (not a.get("url") and a.get("retry", 0) < time.time()):
        with av_sem:
            a = av.get(cid) if (av.get(cid) or {}).get("url") else fetch_avatar(cid)
    if not a.get("url"):
        abort(404)
    r = redirect(a["url"], 302)
    r.headers["Cache-Control"] = "public, max-age=86400"
    return r


ppool = ThreadPoolExecutor(16)   # chunk read-ahead
hpool = ThreadPoolExecutor(6)    # shorts head prefetch
HEADC, HEAD_ORDER = {}, []
CH1, CH = 1024 * 1024, 4 * 1024 * 1024


def rng(f, s0, e0):
    h = dict(f["h"]); h["Range"] = f"bytes={s0}-{e0}"
    r = None
    for _ in range(2):
        try:
            r = S.get(f["url"], headers=h, timeout=15)
            if r.status_code < 400:
                return r
        except Exception:
            r = None
    return r


def _total(r):
    m = re.search(r"/(\d+)$", r.headers.get("Content-Range", ""))
    return int(m.group(1)) if m else int(r.headers.get("Content-Length", 0))


@app.route("/stream/<vid>")
def stream(vid):
    kind = "a" if request.args.get("a") == "1" else request.args.get("k", "m")
    h = int(request.args.get("h", 0) or 0)
    m = re.match(r"bytes=(\d*)-(\d*)", request.headers.get("Range", "bytes=0-"))
    s0 = int(m.group(1) or 0) if m else 0
    e0 = int(m.group(2)) if m and m.group(2) else None
    first = r = f = None
    for attempt in (0, 1):
        try:
            c = resolve(vid)
        except Exception as e:
            return str(e), 502
        f = pick(c, kind, h) or pick(c, "m")
        if not f:
            abort(502)
        hk = (vid, kind, h)
        hd = HEADC.get(hk)
        if hd and s0 < len(hd["b"]):                      # served from the prefetched first chunk
            first, total, ct = hd["b"][s0:], hd["total"], hd["ct"]
            if e0 is not None:
                first = first[: e0 - s0 + 1]
            break
        r = rng(f, s0, min(s0 + CH1 - 1, e0) if e0 is not None else s0 + CH1 - 1)
        if r is not None and r.status_code < 400:
            first, total, ct = r.content, _total(r), r.headers.get("Content-Type", "video/mp4")
            break
        cache.pop(vid, None)
    else:
        abort(502)
    end = min(e0, total - 1) if e0 is not None else total - 1
    first = first[: end - s0 + 1]
    hdr = {"Content-Type": ct, "Accept-Ranges": "bytes", "Content-Length": str(end - s0 + 1),
           "Cache-Control": "private, max-age=3600"}
    ranged = "Range" in request.headers
    if ranged:
        hdr["Content-Range"] = f"bytes {s0}-{end}/{total}"

    def gen():
        pos = s0 + len(first)
        yield first
        futs = []
        def sched(p):
            if p <= end:
                futs.append(ppool.submit(rng, f, p, min(p + CH - 1, end)))
                return p + CH
            return p
        nxt = pos
        for _ in range(2):                               # read-ahead: 2 chunks in parallel
            nxt = sched(nxt)
        try:
            while futs:
                rr = futs.pop(0).result()
                if rr is None or rr.status_code >= 400:
                    return
                nxt = sched(nxt)
                yield rr.content
        except GeneratorExit:
            for x in futs:
                x.cancel()

    return Response(gen(), status=206 if ranged else 200, headers=hdr)


@app.route("/api/warm/<vid>")
def warm_one(vid):
    if re.fullmatch(r"[\w-]{11}", vid):
        hpool.submit(lambda: resolve(vid))
    return "", 204


@app.route("/api/prefetch")
def prefetch():
    ids = [x for x in request.args.get("ids", "").split(",") if re.fullmatch(r"[\w-]{11}", x)][:12]

    def job(vid):
        try:
            c = resolve(vid)
            f = pick(c, "m")
            if not f or (vid, "m", 0) in HEADC:
                return
            n = int(min(3 * CH1, max(256 * 1024, (f["tbr"] or 600) * 1000 / 8 * 5)))   # ~first 5 seconds
            r = rng(f, 0, n - 1)
            if r is not None and r.status_code < 400:
                HEADC[(vid, "m", 0)] = {"b": r.content, "total": _total(r), "ct": r.headers.get("Content-Type", "video/mp4")}
                HEAD_ORDER.append((vid, "m", 0))
                while len(HEAD_ORDER) > 60:
                    HEADC.pop(HEAD_ORDER.pop(0), None)
        except Exception:
            pass
    for v in ids:                                         # FIFO: the current short is first in the list
        hpool.submit(job, v)
    return "", 204


@app.route("/api/quick/<vid>")
def quick(vid):
    try:
        r = S.get("https://www.youtube.com/oembed", params={"url": "https://youtu.be/" + vid, "format": "json"}, timeout=6).json()
        return jsonify({"title": r.get("title"), "channel": r.get("author_name")})
    except Exception:
        return jsonify({})


def pdl(f, path, workers=8, chunk=6 * 1024 * 1024):
    r = rng(f, 0, 0)
    total = _total(r)
    with open(path, "wb") as fh:
        fh.truncate(total)
    fd = os.open(path, os.O_WRONLY)

    def part(s0):
        rr = rng(f, s0, min(s0 + chunk - 1, total - 1))
        os.pwrite(fd, rr.content, s0)
    try:
        with ThreadPoolExecutor(workers) as ex:
            list(ex.map(part, range(0, total, chunk)))
    finally:
        os.close(fd)


@app.route("/download/<vid>")
def download(vid):
    h = int(request.args.get("h", 0) or 0)
    try:
        c = resolve(vid)
    except Exception as e:
        return str(e), 502
    d = tempfile.mkdtemp()
    name = re.sub(r'[\\/:*?"<>|]+', "", c["title"] or vid)[:80] or vid
    vf = pick(c, "v", h) if shutil.which("ffmpeg") else None
    af = pick(c, "a")
    out = os.path.join(d, name + ".mp4")
    if vf and af and (not c["muxh"] or vf["height"] > c["muxh"]):
        jobs = [pool.submit(pdl, vf, d + "/v.mp4"), pool.submit(pdl, af, d + "/a.m4a")]   # parallel ranged downloads
        for j in jobs:
            j.result()
        os.system(f'ffmpeg -loglevel error -y -i "{d}/v.mp4" -i "{d}/a.m4a" -c copy -movflags +faststart "{out}"')
    else:
        pdl(pick(c, "m"), out)
    resp = send_file(out, as_attachment=True, download_name=os.path.basename(out))
    resp.call_on_close(lambda: shutil.rmtree(d, ignore_errors=True))
    return resp


chc = {}


def flat(url, n):
    k = (url, n)
    c = chc.get(k)
    if c and c[0] > time.time():
        return c[1]
    with YoutubeDL({**BASE, "extract_flat": True, "skip_download": True, "playlistend": n}) as y:
        r = y.extract_info(url, download=False)
    chc[k] = (time.time() + 600, r)
    return r


def find_all(o, key, out):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == key:
                out.append(v)
            else:
                find_all(v, key, out)
    elif isinstance(o, list):
        for v in o:
            find_all(v, key, out)
    return out


def posts_of(cid):
    hd = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"}
    for tab in ("posts", "community"):
        try:
            html = S.get(f"https://www.youtube.com/channel/{cid}/{tab}", headers=hd, timeout=12).text
            m = re.search(r"ytInitialData\s*=\s*(\{.+?\});</script>", html, re.S)
            if not m:
                continue
            out = []
            for p in find_all(json.loads(m.group(1)), "backstagePostRenderer", []):
                txt = "".join(x.get("text", "") for x in (p.get("contentText") or {}).get("runs", []))
                img = None
                for im in find_all(p.get("backstageAttachment", {}), "thumbnails", []):
                    if im:
                        img = im[-1]["url"]; break
                out.append({"id": p.get("postId"), "text": txt, "time": ((p.get("publishedTimeText") or {}).get("runs") or [{}])[0].get("text"),
                            "likes": (p.get("voteCount") or {}).get("simpleText"), "img": img})
            if out:
                return out
        except Exception:
            continue
    return []


@app.route("/api/channel/<cid>")
def api_channel(cid):
    if not re.fullmatch(r"[\w-]{10,40}", cid):
        abort(404)
    tab = request.args.get("tab", "videos")
    p = max(1, int(request.args.get("page", 1)))
    try:
        if tab == "posts":
            return jsonify({"items": posts_of(cid) if p == 1 else []})
        r = flat(f"https://www.youtube.com/channel/{cid}/{'shorts' if tab == 'shorts' else 'videos'}", 24 * p)
        items = [{"id": e["id"], "title": e.get("title"), "channel": r.get("channel") or r.get("uploader"), "cid": cid,
                  "dur": e.get("duration"), "views": e.get("view_count"), "short": tab == "shorts",
                  "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg"}
                 for e in (r.get("entries") or [])[24 * (p - 1):] if e and len(e.get("id", "")) == 11]
        return jsonify({"name": r.get("channel") or r.get("uploader") or r.get("title"),
                        "subs": r.get("channel_follower_count"), "items": items})
    except Exception as e:
        return jsonify({"items": [], "error": str(e)[:200]})


def page():
    r = send_from_directory(STATIC, "index.html")
    r.headers["Cache-Control"] = "no-store"
    return r


@app.route("/")
@app.route("/watch")
@app.route("/results")
@app.route("/shorts")
@app.route("/channel")
def pages():
    return page()


def warm():
    langs = {"en"}
    sysl = os.environ.get("LANG", "en")[:2].lower()
    if sysl in DEFAULTS:
        langs.add(sysl)
    for l in langs:
        for q in DEFAULTS[l][:2]:
            try:
                ysearch(q, 12)
            except Exception:
                pass


if __name__ == "__main__":
    threading.Thread(target=warm, daemon=True).start()
    PORT = int(os.environ.get("PORT", 8765))
    print("JS runtime:", list(JSR) or "NONE (optional: install nodejs for fewer extraction errors)")
    print(f"ytnetwork at http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
