# ytnetwork
Run `bash start.sh`, then open http://localhost:8765/
The interface language follows the browser language automatically (11 languages, English fallback). There is no language picker.
No API keys: search, channel avatars and comments come from yt-dlp.
Files: server.py (API + streaming), static/index.html, static/app.js, static/style.css, start.sh.
