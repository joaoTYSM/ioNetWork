(() => {
"use strict";
const $ = (s, e = document) => e.querySelector(s);
const STR = {
en: "Home|Shorts|Music|Subscriptions|Search|Subscribe|Subscribed|Download|Share|{n} views|{n} subscribers|Comments|Top comments|Newest first|{n} replies|...more|Show less|Up next|Autoplay|Playback speed|Normal|Music mode|Video mode|Picture in picture|Fullscreen|No comments yet|Pinned|Chapters|Show more comments|All|Gaming|News|Sports|Movies|Comedy|Something went wrong|Popup window",
pt: "Início|Shorts|Música|Inscrições|Pesquisar|Inscrever-se|Inscrito|Baixar|Compartilhar|{n} visualizações|{n} inscritos|Comentários|Principais comentários|Mais recentes|{n} respostas|...mais|Mostrar menos|A seguir|Reprodução automática|Velocidade|Normal|Modo música|Modo vídeo|Picture-in-picture|Tela cheia|Nenhum comentário ainda|Fixado|Capítulos|Mostrar mais comentários|Tudo|Jogos|Notícias|Esportes|Filmes|Comédia|Algo deu errado|Janela flutuante",
es: "Inicio|Shorts|Música|Suscripciones|Buscar|Suscribirse|Suscrito|Descargar|Compartir|{n} visualizaciones|{n} suscriptores|Comentarios|Comentarios destacados|Más recientes|{n} respuestas|...más|Mostrar menos|A continuación|Reproducción automática|Velocidad|Normal|Modo música|Modo vídeo|Imagen en imagen|Pantalla completa|Aún no hay comentarios|Fijado|Capítulos|Mostrar más comentarios|Todo|Videojuegos|Noticias|Deportes|Películas|Comedia|Algo salió mal|Ventana emergente",
fr: "Accueil|Shorts|Musique|Abonnements|Rechercher|S'abonner|Abonné|Télécharger|Partager|{n} vues|{n} abonnés|Commentaires|Meilleurs commentaires|Plus récents|{n} réponses|...plus|Afficher moins|À suivre|Lecture automatique|Vitesse de lecture|Normal|Mode musique|Mode vidéo|Picture-in-picture|Plein écran|Aucun commentaire|Épinglé|Chapitres|Afficher plus de commentaires|Tout|Jeux vidéo|Actualités|Sports|Films|Humour|Une erreur s'est produite|Fenêtre flottante",
de: "Startseite|Shorts|Musik|Abos|Suchen|Abonnieren|Abonniert|Herunterladen|Teilen|{n} Aufrufe|{n} Abonnenten|Kommentare|Top-Kommentare|Neueste zuerst|{n} Antworten|...mehr|Weniger anzeigen|Als Nächstes|Autoplay|Wiedergabegeschwindigkeit|Normal|Musikmodus|Videomodus|Bild-in-Bild|Vollbild|Noch keine Kommentare|Angeheftet|Kapitel|Weitere Kommentare anzeigen|Alle|Gaming|Nachrichten|Sport|Filme|Comedy|Etwas ist schiefgelaufen|Popup-Fenster",
it: "Home|Shorts|Musica|Iscrizioni|Cerca|Iscriviti|Iscritto|Scarica|Condividi|{n} visualizzazioni|{n} iscritti|Commenti|Commenti principali|Più recenti|{n} risposte|...altro|Mostra meno|Prossimo|Riproduzione automatica|Velocità|Normale|Modalità musica|Modalità video|Picture-in-picture|Schermo intero|Nessun commento|Fissato|Capitoli|Mostra altri commenti|Tutto|Videogiochi|Notizie|Sport|Film|Commedia|Qualcosa è andato storto|Finestra popup",
ja: "ホーム|ショート|音楽|登録チャンネル|検索|チャンネル登録|登録済み|ダウンロード|共有|{n} 回視聴|登録者 {n} 人|コメント|トップコメント|新しい順|返信 {n} 件|...もっと見る|一部を表示|次の動画|自動再生|再生速度|標準|音楽モード|動画モード|ピクチャー イン ピクチャー|全画面|コメントはまだありません|固定|チャプター|コメントをさらに表示|すべて|ゲーム|ニュース|スポーツ|映画|お笑い|問題が発生しました|ポップアップ",
ko: "홈|Shorts|음악|구독|검색|구독|구독중|다운로드|공유|조회수 {n}회|구독자 {n}명|댓글|인기 댓글|최신순|답글 {n}개|...더보기|간단히 보기|다음 동영상|자동 재생|재생 속도|보통|음악 모드|동영상 모드|PIP|전체 화면|아직 댓글이 없습니다|고정됨|챕터|댓글 더보기|전체|게임|뉴스|스포츠|영화|코미디|문제가 발생했습니다|팝업 창",
ru: "Главная|Shorts|Музыка|Подписки|Поиск|Подписаться|Вы подписаны|Скачать|Поделиться|{n} просмотров|{n} подписчиков|Комментарии|Популярные|Сначала новые|Ответов: {n}|...ещё|Свернуть|Далее|Автовоспроизведение|Скорость|Обычная|Режим музыки|Режим видео|Картинка в картинке|Во весь экран|Комментариев пока нет|Закреплено|Главы|Ещё комментарии|Все|Игры|Новости|Спорт|Фильмы|Юмор|Что-то пошло не так|Всплывающее окно",
hi: "होम|Shorts|संगीत|सदस्यताएँ|खोजें|सदस्यता लें|सदस्यता ली गई|डाउनलोड|शेयर करें|{n} व्यू|{n} सब्सक्राइबर|टिप्पणियाँ|शीर्ष टिप्पणियाँ|नई पहले|{n} जवाब|...और देखें|कम दिखाएं|अगला|ऑटोप्ले|चलाने की गति|सामान्य|संगीत मोड|वीडियो मोड|पिक्चर-इन-पिक्चर|फ़ुलस्क्रीन|अभी कोई टिप्पणी नहीं|पिन किया गया|चैप्टर|और टिप्पणियाँ दिखाएं|सभी|गेमिंग|समाचार|खेल|फ़िल्में|कॉमेडी|कुछ गड़बड़ हो गई|पॉपअप विंडो",
ar: "الرئيسية|Shorts|الموسيقى|الاشتراكات|بحث|اشتراك|تم الاشتراك|تنزيل|مشاركة|{n} مشاهدة|{n} مشترك|التعليقات|أهم التعليقات|الأحدث أولاً|{n} ردود|...المزيد|عرض أقل|التالي|التشغيل التلقائي|سرعة التشغيل|عادي|وضع الموسيقى|وضع الفيديو|صورة داخل صورة|ملء الشاشة|لا توجد تعليقات بعد|مثبت|الفصول|عرض المزيد من التعليقات|الكل|الألعاب|الأخبار|الرياضة|الأفلام|الكوميديا|حدث خطأ ما|نافذة منبثقة"};
const KEYS = "home shorts music subscriptions search subscribe subscribed download share views subscribers comments top newest replies more less upNext autoplay speed normal musicMode videoMode pip fullscreen noComments pinned chapters showMoreComments all gaming news sports movies comedy error popup".split(" ");
const parse = s => Object.fromEntries(s.split("|").map((v, i) => [KEYS[i], v]));
const detect = () => { for (const l of navigator.languages || [navigator.language]) { const c = String(l || "").slice(0, 2).toLowerCase(); if (STR[c]) return c; } return "en"; };
const L = detect();
const CUR = {...parse(STR.en), ...parse(STR[L])};
const t = (k, n) => (CUR[k] || k).replace("{n}", n == null ? "" : n);
document.documentElement.lang = L;
if (L === "ar") document.documentElement.dir = "rtl";
const NF = new Intl.NumberFormat(L, {notation: "compact"}), NA = new Intl.NumberFormat(L);
const DF = new Intl.DateTimeFormat(L, {dateStyle: "medium"}), RF = new Intl.RelativeTimeFormat(L, {numeric: "auto"});
const fmtN = n => n == null ? "" : NF.format(n);
const rel = ts => { if (!ts) return ""; const s = ts - Date.now() / 1000; for (const [n, v] of [["year", 31536000], ["month", 2592000], ["week", 604800], ["day", 86400], ["hour", 3600], ["minute", 60]]) if (Math.abs(s) >= v) return RF.format(Math.round(s / v), n); return RF.format(0, "second"); };
const fmtT = s => { s = Math.max(0, s | 0); const h = s / 3600 | 0, m = (s % 3600) / 60 | 0, x = s % 60; return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(x).padStart(2, "0"); };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
const store = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
const I = {
  play: "M8 5v14l11-7z", pause: "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
  next: "M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z", prev: "M6 6h2v12H6zm3.5 6 8.5 6V6z",
  vol: "M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z",
  mute: "M16.5 12A4.5 4.5 0 0 0 14 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0 0 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 0 0 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4 9.91 6.09 12 8.18V4z",
  fs: "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z",
  fsx: "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z",
  set: "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
  pip: "M19 7h-8v6h8V7zm2-4H3a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h18a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm0 16H3V5h18v14z",
  pop: "M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.6l-9.8 9.8 1.4 1.4L19 6.4V10h2V3h-7z",
  hp: "M12 3a9 9 0 0 0-9 9v7a2 2 0 0 0 2 2h3v-8H5v-1a7 7 0 0 1 14 0v1h-3v8h3a2 2 0 0 0 2-2v-7a9 9 0 0 0-9-9z",
  vid: "M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4z",
  music: "M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z",
  home: "M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z",
  shorts: "M7 2h10a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3zm3 7v6l5-3-5-3z",
  dl: "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
  cp: "M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z",
  like: "M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z",
  share: "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z",
  down: "M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z",
  right: "M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z",
  back: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
  check: "M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
  sort: "M3 18h6v-2H3v2zM3 6v2h18V6H3zm0 7h12v-2H3v2z",
  heart: "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z",
  pin: "M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z",
  ok: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"};
const ic = n => `<svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="${I[n]}"/></svg>`;
const hist = store("yn_hist", {langs: {}, ch: [], t: []});
let subs = store("yn_subs", {});
function remember(i) {
  if (i.lang) hist.langs[i.lang] = (hist.langs[i.lang] || 0) + 1;
  if (i.channel) hist.ch = [i.channel, ...hist.ch.filter(x => x !== i.channel)].slice(0, 6);
  if (i.title) hist.t = [i.title.split(/[|\-–(]/)[0].trim().slice(0, 40), ...hist.t].slice(0, 6);
  save("yn_hist", hist);
}
function mix() {
  const tot = Object.values(hist.langs).reduce((a, b) => a + b, 0);
  if (tot < 5) return 0;
  return Math.min(.4, (tot - (hist.langs[L] || 0)) / tot);
}
const interests = () => [...Object.keys(subs).slice(0, 2), ...hist.ch.slice(0, 1), ...hist.t.slice(0, 1)].filter(Boolean);
async function feed(p, cb, signal) {
  const r = await fetch("/api/feed?" + new URLSearchParams(p), {signal});
  const rd = r.body.getReader(), td = new TextDecoder(); let buf = "";
  for (;;) {
    const {done, value} = await rd.read(); if (done) break;
    buf += td.decode(value, {stream: true}); let k;
    while ((k = buf.indexOf("\n")) >= 0) { const l = buf.slice(0, k); buf = buf.slice(k + 1); if (l.trim()) cb(JSON.parse(l)); }
  }
}
const avatar = (cid, name, cls = "") => {
  const n = esc((name || "?").trim()[0] || "?");
  return cid ? `<span class="av skel ${cls}" data-n="${n}"><img loading="lazy" src="/avatar/${cid}" onload="this.parentNode.classList.remove('skel')" onerror="this.parentNode.classList.remove('skel');this.remove()"></span>` : `<span class="av ${cls}" data-n="${n}"></span>`;
};
const thumbImg = (src, cls = "") => `<img class="${cls}" loading="lazy" src="${src}" style="opacity:0" onload="this.style.opacity=1">`;
const mk = (h, c) => { const d = document.createElement("div"); d.className = c; d.innerHTML = h; return d; };
const skCard = () => mk(`<div class="th skel"></div><div class="meta"><span class="av skel"></span><div class="mx"><i class="ln skel"></i><i class="ln s skel"></i></div></div>`, "card");
const skRow = () => mk(`<div class="th skel"></div><div class="mx"><i class="ln m skel"></i><i class="ln s skel"></i><i class="ln xs skel"></i></div>`, "rrow");
const skRc = () => mk(`<div class="th skel"></div><div class="mx"><i class="ln skel"></i><i class="ln s skel"></i></div>`, "rc");
const skCm = () => mk(`<span class="av l skel"></span><div class="cb"><i class="ln xs skel"></i><i class="ln skel"></i><i class="ln m skel"></i></div>`, "cm");
const link = (i, extra) => { const a = document.createElement("a"); a.href = `/watch?v=${i.id}`; a.onclick = e => { if (e.ctrlKey || e.metaKey) return; e.preventDefault(); nav(a.getAttribute("href"), i); }; return a; };
function card(i) {
  const a = link(i); a.className = "card";
  a.innerHTML = `<div class="th skel">${thumbImg(i.thumb)}<span class="dur">${fmtT(i.dur)}</span></div><div class="meta">${avatar(i.cid, i.channel)}<div class="mx"><h3>${esc(i.title)}</h3><p>${esc(i.channel)}${i.views != null ? "<br>" + t("views", fmtN(i.views)) : ""}</p></div></div>`;
  $(".th img", a).addEventListener("load", e => e.target.parentNode.classList.remove("skel"));
  return a;
}
function row(i) {
  const a = link(i); a.className = "rrow";
  a.innerHTML = `<div class="th skel">${thumbImg(i.thumb)}<span class="dur">${fmtT(i.dur)}</span></div><div class="mx rb2"><h3>${esc(i.title)}</h3><p>${i.views != null ? t("views", fmtN(i.views)) : ""}</p><div class="rch">${avatar(i.cid, i.channel, "sm")}<span>${esc(i.channel)}</span></div></div>`;
  $(".th img", a).addEventListener("load", e => e.target.parentNode.classList.remove("skel"));
  return a;
}
function rc(i, cur) {
  const a = link(i); a.className = "rc" + (cur ? " cur" : "");
  a.innerHTML = `<div class="th skel">${thumbImg(i.thumb)}<span class="dur">${fmtT(i.dur)}</span></div><div class="mx"><h4>${esc(i.title)}</h4><p>${esc(i.channel)}<br>${i.views != null ? t("views", fmtN(i.views)) : ""}</p></div>`;
  $(".th img", a).addEventListener("load", e => e.target.parentNode.classList.remove("skel"));
  return a;
}
function makeFeed(list, more, sk, build, params, n0 = 8) {
  const S = {page: 1, busy: false, seen: new Set(), ac: null, dead: false};
  const io = new IntersectionObserver(e => { if (e[0].isIntersecting) { io.unobserve(more); load(); } }, {rootMargin: "900px"});
  async function load() {
    if (S.busy || S.dead) return; S.busy = true; const ac = S.ac = new AbortController();
    const sks = Array.from({length: n0}, () => { const d = sk(); list.append(d); return d; }); let n = 0;
    try { await feed(params(S.page), i => { if (S.dead || S.seen.has(i.id)) return; S.seen.add(i.id); n++; const s = sks.shift(), c = build(i); s ? s.replaceWith(c) : list.append(c); S.on?.(i); }, ac.signal); } catch {}
    sks.forEach(s => s.remove());
    if (S.dead) return; S.page++; S.busy = false;
    if (!n && S.page < 5) load(); else io.observe(more);
  }
  S.load = load;
  S.stop = () => { S.dead = true; S.ac?.abort(); io.disconnect(); };
  S.prefill = items => { items.forEach(i => { S.seen.add(i.id); list.append(build(i)); }); S.page = 2; io.observe(more); };
  return S;
}
const views = ["home", "results", "watch", "shorts"];
function show(v) { views.forEach(x => $("#" + x).hidden = x !== v); document.body.className = document.body.className.replace(/\bv-\w+/g, "").trim() + " v-" + v + (document.body.classList.contains("popup") ? " popup" : ""); renderSide(v); }
let hint = null, trail = [];
function nav(url, item) { hint = item || null; history.pushState(null, "", url); route(); }
window.addEventListener("popstate", route);
function route() {
  stopWatch(); stopShorts(); HF?.stop(); RF2?.stop(); closeSide();
  const p = new URLSearchParams(location.search), pn = location.pathname;
  const pop = p.get("popup") === "1";
  if (pn !== "/watch") trail = [];
  if (pn === "/watch" && p.get("v")) { document.body.classList.toggle("popup", pop); return openWatch(p.get("v"), hint); }
  document.body.classList.remove("popup");
  if (pn === "/shorts") return openShorts();
  if (pn === "/results") return openResults(p.get("search_query") || "");
  show("home"); startHome(0);
}
const CHIPS = ["all", "music", "gaming", "news", "sports", "movies", "comedy"];
let HF = null, RF2 = null, chip = 0;
const homeKey = () => "yn_home_" + L;
function startHome(c) {
  HF?.stop(); chip = c; $("#q").value = ""; $("#grid").innerHTML = "";
  $("#chips").innerHTML = CHIPS.map((k, i) => `<button class="chip ${i === c ? "on" : ""}" data-c="${i}">${t(k)}</button>`).join("");
  const params = page => ({q: chip ? t(CHIPS[chip]) : interests().join("|"), l: L, mix: chip ? 0 : mix(), page});
  HF = makeFeed($("#grid"), $("#more"), skCard, card, params);
  const cached = chip === 0 ? store(homeKey(), null) : null, keep = [];
  if (cached && cached.length) {
    HF.prefill(cached);
    const buf = []; feed(params(1), i => buf.push(i)).then(() => buf.length && save(homeKey(), buf.slice(0, 24))).catch(() => {});
  } else {
    HF.on = i => { if (chip === 0 && keep.length < 24) { keep.push(i); if (keep.length === 24 || keep.length % 6 === 0) save(homeKey(), keep); } };
    HF.load();
  }
}
$("#chips").onclick = e => { const b = e.target.closest(".chip"); if (b) startHome(+b.dataset.c); };
function openResults(q) {
  show("results"); $("#q").value = q; $("#rl").innerHTML = "";
  RF2 = makeFeed($("#rl"), $("#rmore"), skRow, row, page => ({q, l: "a", page}), 6);
  RF2.load();
}
function md(s0) {
  let s = esc(s0);
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a class="x" href="$2">$1</a>');
  s = s.replace(/(^|[\s>(])(https?:\/\/[^\s<)]+)/g, '$1<a class="x" href="$2">$2</a>');
  s = s.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/(^|\s)#([\p{L}\d_]{2,})/gu, '$1<a data-q="#$2">#$2</a>');
  s = s.replace(/(^|[\s(])((?:\d{1,2}:)?\d{1,2}:\d{2})(?=[\s).,]|$)/g, (m, a, ts) => `${a}<a data-t="${ts.split(":").reduce((x, y) => x * 60 + +y, 0)}">${ts}</a>`);
  return s;
}
document.addEventListener("click", e => {
  const a = e.target.closest("a"); if (!a) return;
  if (a.classList.contains("x")) { e.preventDefault(); e.stopPropagation(); window.open(a.href, "_blank", "popup,width=1000,height=700,noopener"); }
  else if (a.dataset.q) { e.preventDefault(); e.stopPropagation(); nav(`/results?search_query=${encodeURIComponent(a.dataset.q)}`); }
  else if (a.dataset.t && W.v) { e.preventDefault(); e.stopPropagation(); W.v.currentTime = +a.dataset.t; W.v.play(); scrollTo({top: 0, behavior: "smooth"}); }
}, true);
let W = {};
function stopWatch() {
  if (W.v) { W.v.pause(); W.v.removeAttribute("src"); W.v.load(); }
  clearTimeout(W.idle); document.removeEventListener("fullscreenchange", W.fsh || (() => {})); W = {}; $("#watch").innerHTML = "";
  document.body.style.overflow = "";
  if ("mediaSession" in navigator) navigator.mediaSession.metadata = null;
}
const isFs = () => W.pl && (document.fullscreenElement === W.pl || document.webkitFullscreenElement === W.pl || W.pl.classList.contains("pfs"));
async function toggleFs() {
  const pl = W.pl; if (!pl) return;
  if (isFs()) {
    if (pl.classList.contains("pfs")) { pl.classList.remove("pfs"); document.body.style.overflow = ""; fsSync(); }
    else (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    try { screen.orientation?.unlock?.(); } catch {}
    return;
  }
  const req = pl.requestFullscreen || pl.webkitRequestFullscreen;
  if (req) { try { await req.call(pl); try { await screen.orientation?.lock?.("landscape"); } catch {} } catch { pl.classList.add("pfs"); document.body.style.overflow = "hidden"; fsSync(); } }
  else { pl.classList.add("pfs"); document.body.style.overflow = "hidden"; fsSync(); }
}
function fsSync() { const b = $("#fs"); if (b) b.innerHTML = ic(isFs() ? "fsx" : "fs"); }
const SPEEDS = [.25, .5, .75, 1, 1.25, 1.5, 1.75, 2];
function descBox(i) {
  const d = i.date ? DF.format(new Date(+i.date.slice(0, 4), +i.date.slice(4, 6) - 1, +i.date.slice(6))) : "";
  const tags = [...new Set(i.desc.match(/#[\p{L}\d_]{2,}/gu) || [])].slice(0, 3).map(x => `<a data-q="${esc(x)}">${esc(x)}</a>`).join(" ");
  const ch = (i.chapters || []).length ? `<div class="chs tg"><h4>${t("chapters")}</h4>${i.chapters.map(c => `<button class="chp" data-t="${c.start | 0}"><b>${fmtT(c.start)}</b><span>${esc(c.title)}</span></button>`).join("")}</div>` : "";
  const box = $("#ds"); box.className = "desc"; box.classList.remove("skel");
  box.innerHTML = `<div class="dh"><span>${t("views", NA.format(i.views || 0))}</span><span>${d}</span>${tags}</div><div class="db">${md(i.desc || "")}</div><button class="dm">${t("more")}</button>${ch}`;
  const db = $(".db", box), dm = $(".dm", box);
  if (db.scrollHeight <= db.clientHeight + 2 && !ch) dm.hidden = true;
  box.onclick = e => {
    if (e.target.closest("a") || e.target.closest(".chp")) { const c = e.target.closest(".chp"); if (c && W.v) { W.v.currentTime = +c.dataset.t; W.v.play(); scrollTo({top: 0, behavior: "smooth"}); } return; }
    const open = box.classList.toggle("open"); dm.textContent = open ? t("less") : t("more"); dm.hidden = false;
  };
}
function cmEl(c, reply) {
  const d = document.createElement("div"); d.className = "cm" + (reply ? " rp" : "");
  const reps = c.replies || [];
  d.innerHTML = `${avatar(null, c.author, reply ? "sm" : "l")}<div class="cb"><div class="ch">${c.pinned ? `<span class="pin">${ic("pin")} ${t("pinned")}</span>` : ""}<b class="${c.creator ? "cr" : ""}">${esc(c.author)}</b><small>${rel(c.ts)}</small></div><div class="ct">${md(c.text)}</div><button class="rm" hidden>${t("more")}</button><div class="ca"><button class="lk">${ic("like")}</button><span>${c.likes ? fmtN(c.likes) : ""}</span><button class="flip dl">${ic("like")}</button>${c.heart ? `<span class="ht">${ic("heart")}</span>` : ""}<button class="cc">${ic("cp")}</button></div>${reps.length ? `<button class="rt">${ic("down")} ${t("replies", reps.length)}</button><div class="rpl" hidden></div>` : ""}</div>`;
  if (c.thumb) { const av = $(".av", d); av.classList.add("skel"); const im = new Image(); im.onload = () => { av.classList.remove("skel"); av.append(im); }; im.onerror = () => av.classList.remove("skel"); im.src = c.thumb; im.style.cssText = "position:absolute;inset:0;width:100%;height:100%;object-fit:cover"; }
  const ct = $(".ct", d), rm = $(".rm", d);
  requestAnimationFrame(() => { if (ct.scrollHeight > ct.clientHeight + 2) rm.hidden = false; });
  rm.onclick = () => { const o = ct.classList.toggle("open"); rm.textContent = o ? t("less") : t("more"); };
  $(".lk", d).onclick = e => e.currentTarget.classList.toggle("act");
  $(".dl", d).onclick = e => e.currentTarget.classList.toggle("act");
  $(".cc", d).onclick = () => navigator.clipboard?.writeText(c.text);
  const rt = $(".rt", d);
  if (rt) rt.onclick = () => { const box = $(".rpl", d), o = rt.classList.toggle("open"); box.hidden = !o; if (o && !box.children.length) reps.forEach(r => box.append(cmEl(r, true))); };
  return d;
}
function setupComments(id) {
  const C = {sort: "top", n: 20, seen: new Set(), busy: false};
  const cm = $("#cmt");
  cm.innerHTML = `<div class="cmh"><h2 id="cmn"><i class="ln skel" style="width:120px;height:20px;display:inline-block;margin:0"></i></h2><button class="srt" id="srt">${ic("sort")} ${t("top")}</button><div class="srm" id="srm" hidden><button data-s="top">${t("top")}</button><button data-s="new">${t("newest")}</button></div></div><div id="cml"></div><div id="cmx"></div>`;
  const list = $("#cml"), ext = $("#cmx");
  async function load(reset) {
    if (C.busy || W.id !== id) return; C.busy = true; ext.innerHTML = "";
    if (reset) { list.innerHTML = ""; C.seen.clear(); }
    const sk = Array.from({length: reset ? 5 : 3}, skCm); sk.forEach(s => list.append(s));
    let data = {items: [], count: null};
    try { data = await (await fetch(`/api/comments/${id}?sort=${C.sort}&n=${C.n}`)).json(); } catch {}
    sk.forEach(s => s.remove()); C.busy = false; if (W.id !== id) return;
    const fresh = data.items.filter(c => !C.seen.has(c.id));
    fresh.forEach(c => { C.seen.add(c.id); list.append(cmEl(c)); });
    $("#cmn").textContent = `${t("comments")}${data.count != null ? " · " + NA.format(data.count) : ""}`;
    if (!C.seen.size) list.innerHTML = `<p style="color:var(--mu)">${t("noComments")}</p>`;
    else if (fresh.length && C.n < 100) { ext.innerHTML = `<button class="more">${t("showMoreComments")}</button>`; $(".more", ext).onclick = () => { C.n += 20; load(false); }; }
  }
  $("#srt").onclick = e => { e.stopPropagation(); $("#srm").hidden = !$("#srm").hidden; };
  $("#srm").onclick = e => { const b = e.target.closest("button"); if (!b) return; C.sort = b.dataset.s; C.n = 20; $("#srt").innerHTML = `${ic("sort")} ${t(C.sort)}`; $("#srm").hidden = true; load(true); };
  load(true);
}
document.addEventListener("click", e => { const m = $("#srm"); if (m && !m.hidden && !e.target.closest("#srm")) m.hidden = true; });
async function openWatch(id, item) {
  show("watch"); scrollTo(0, 0);
  W = {id, music: store("yn_music", false), rel: []};
  const w = $("#watch"), th = `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
  w.innerHTML = `<div class="pw"><div class="player ${W.music ? "music" : ""} paused" id="pl" tabindex="-1">
<video id="vid" playsinline webkit-playsinline preload="auto" poster="${th}" autoplay></video>
<div class="mz"><div class="mbg" style="background-image:url(${th})"></div><div class="mc"><div class="art"><img src="${th}" alt=""></div><div class="m1" id="m1"></div><div class="m2" id="m2"></div></div></div>
<div class="bz on" id="bz"><i class="spin"></i></div><div class="fl" id="fl"></div><div class="dt l" id="dtl">−10</div><div class="dt r" id="dtr">+10</div>
<div class="ctl" id="ctl"><div class="pg" id="pg"><div class="bf"></div><div class="pr"></div><div class="kn"></div><div class="tip" id="tip"></div></div>
<div class="row"><button id="pp" class="pb">${ic("play")}</button><button id="nx" class="pb">${ic("next")}</button><div class="vg"><button id="mu">${ic("vol")}</button><input type="range" id="vol" min="0" max="1" step=".05" value="1"></div><span class="tm" id="tm">0:00 / 0:00</span><span class="sp"></span>
<button id="ap" class="swb ${store("yn_ap", true) ? "on" : ""}" title="${t("autoplay")}"><span class="sw"><i></i></span></button><button id="mm" title="${t("musicMode")}">${ic(W.music ? "vid" : "hp")}</button><button id="st" title="${t("speed")}">${ic("set")}</button><button id="fs" title="${t("fullscreen")}">${ic("fs")}</button></div></div>
<div class="mn" id="mn" hidden></div></div></div>
<div class="info"><h1 id="tt"></h1><div class="chrow" id="ch"></div><div class="chrow acts" id="ac"></div><div class="desc skel" id="ds" style="height:84px"></div></div>
<aside class="rel"><div class="rhd"><h3>${t("upNext")}</h3></div><div id="rel"></div></aside><div id="cmt"></div>`;
  const v = W.v = $("#vid"), pl = W.pl = $("#pl");
  v.src = `/stream/${id}${W.music ? "?a=1" : ""}`;
  setupPlayer(v, pl);
  const skeletonInfo = () => { $("#tt").innerHTML = `<i class="ln big skel"></i>`; $("#ch").innerHTML = `<span class="av l skel"></span><div class="mx"><i class="ln xs skel"></i><i class="ln xs skel"></i></div>`; };
  skeletonInfo();
  $("#rel").append(...Array.from({length: 8}, skRc));
  const fill = i => {
    W.item = {...(W.item || {}), ...i, id};
    $("#tt").textContent = i.title || ""; $("#m1").textContent = i.title || ""; $("#m2").textContent = i.channel || "";
    const subd = !!subs[i.channel];
    $("#ch").innerHTML = `<div class="chn">${avatar(i.cid, i.channel, "l")}<div><b>${esc(i.channel)}${i.verified ? ic("ok") : ""}</b><small>${i.subs != null ? t("subscribers", fmtN(i.subs)) : ""}</small></div></div><button class="btn pri" id="sub">${subd ? t("subscribed") : t("subscribe")}</button>`;
    $("#sub").onclick = e => { if (subs[i.channel]) delete subs[i.channel]; else subs[i.channel] = i.cid || 1; save("yn_subs", subs); e.currentTarget.textContent = subs[i.channel] ? t("subscribed") : t("subscribe"); renderSide("watch"); };
  };
  if (item) { W.item = item; fill(item); }
  document.title = item?.title || "ytnetwork";
  let liked = false;
  fetch(`/api/info/${id}`).then(r => r.json()).then(i => {
    if (W.id !== id) return; fill(i); document.title = i.title; remember({...i, id}); W.chapters = i.chapters || [];
    $("#ac").innerHTML = `<div class="grp"><button class="btn" id="lk">${ic("like")} ${fmtN(i.likes)}</button><button class="btn flip" id="dk">${ic("like")}</button></div><button class="btn" id="sh2">${ic("share")} ${t("share")}</button><a class="btn" href="/download/${id}">${ic("dl")} ${t("download")}</a>`;
    $("#lk").onclick = e => { liked = !liked; e.currentTarget.classList.toggle("act", liked); e.currentTarget.innerHTML = `${ic("like")} ${fmtN((i.likes || 0) + (liked ? 1 : 0))}`; };
    $("#sh2").onclick = () => { const u = `${location.origin}/watch?v=${id}`; if (navigator.share) navigator.share({title: i.title, url: u}).catch(() => {}); else navigator.clipboard?.writeText(u); };
    descBox(i); setMS(W.item);
    const q = [i.channel, i.tags?.[0] || (i.title || "").split(" ").slice(0, 3).join(" ")].filter(Boolean).join("|");
    let first = true; const relEl = $("#rel"), sks = [...relEl.children];
    feed({q, l: i.lang || L, page: 1}, x => { if (W.id !== id || x.id === id) return; W.rel.push(x); const s = sks.shift(), c = rc(x); s ? s.replaceWith(c) : relEl.append(c); }).then(() => { sks.forEach(s => s.remove()); }).catch(() => sks.forEach(s => s.remove()));
  }).catch(() => { $("#ds").className = "desc"; $("#ds").style.height = ""; $("#ds").textContent = t("error"); $("#rel").innerHTML = ""; });
  setupComments(id);
  if (W.music) $("#mm").classList.add("on");
}
function playNext() {
  const n = W.rel.find(x => x.id !== W.id && !trail.includes(x.id)) || W.rel.find(x => x.id !== W.id);
  if (n) { trail.push(W.id); nav(`/watch?v=${n.id}`, n); }
}
function playPrev() {
  const v = W.v; if (!v) return;
  if (v.currentTime > 3 || !trail.length) { v.currentTime = 0; return; }
  const id = trail.pop(); nav(`/watch?v=${id}`);
}
function setMusic(on) {
  const v = W.v, t0 = v.currentTime, was = !v.paused; W.music = on; save("yn_music", on);
  W.pl.classList.toggle("music", on); $("#mm").classList.toggle("on", on); $("#mm").innerHTML = ic(on ? "vid" : "hp");
  $("#bz").classList.add("on"); v.src = `/stream/${W.id}${on ? "?a=1" : ""}`;
  v.addEventListener("loadedmetadata", () => { v.currentTime = t0; if (was) v.play().catch(() => {}); }, {once: true});
}
function setupPlayer(v, pl) {
  const pg = $("#pg"), bz = on => $("#bz").classList.toggle("on", on);
  let drag = false, ck = null;
  const dur = () => v.duration || 0;
  const chapterAt = s => { const c = (W.chapters || []).filter(x => x.start <= s).pop(); return c ? c.title : ""; };
  const upd = () => {
    const d = dur(); if (!d) return;
    $("#tm").textContent = `${fmtT(v.currentTime)} / ${fmtT(d)}`;
    if (!drag) pg.style.setProperty("--p", v.currentTime / d * 100 + "%");
    let b = 0; for (let i = 0; i < v.buffered.length; i++) if (v.buffered.start(i) <= v.currentTime + 1) b = v.buffered.end(i);
    pg.style.setProperty("--b", b / d * 100 + "%");
    if ("mediaSession" in navigator && navigator.mediaSession.setPositionState) try { navigator.mediaSession.setPositionState({duration: d, position: Math.min(v.currentTime, d), playbackRate: v.playbackRate}); } catch {}
  };
  v.ontimeupdate = v.onprogress = v.onloadedmetadata = v.ondurationchange = upd;
  const frac = e => { const r = pg.getBoundingClientRect(); return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); };
  const tip = e => { const p = frac(e), tp = $("#tip"), r = pg.getBoundingClientRect(), w = tp.offsetWidth / 2 || 20; tp.style.left = Math.min(r.width - w, Math.max(w, p * r.width)) + "px"; const c = chapterAt(p * dur()); tp.innerHTML = `${c ? `<small>${esc(c)}</small>` : ""}${fmtT(p * dur())}`; };
  pg.onpointerdown = e => { drag = true; pg.classList.add("drag"); pg.setPointerCapture(e.pointerId); pg.style.setProperty("--p", frac(e) * 100 + "%"); tip(e); };
  pg.onpointermove = e => { tip(e); if (drag) pg.style.setProperty("--p", frac(e) * 100 + "%"); };
  pg.onpointerup = e => { if (!drag) return; drag = false; pg.classList.remove("drag"); if (dur()) v.currentTime = frac(e) * dur(); };
  pg.onpointercancel = () => { drag = false; pg.classList.remove("drag"); };
  const flash = n => { const f = $("#fl"); f.innerHTML = ic(n); f.classList.remove("go"); void f.offsetWidth; f.classList.add("go"); };
  const toggle = () => { if (v.paused) { v.play().catch(() => {}); flash("play"); } else { v.pause(); flash("pause"); } };
  const seekBy = d => { v.currentTime = Math.max(0, Math.min(dur() || 1e9, v.currentTime + d)); const el = $(d > 0 ? "#dtr" : "#dtl"); el.textContent = (d > 0 ? "+" : "−") + Math.abs(d); el.classList.remove("go"); void el.offsetWidth; el.classList.add("go"); };
  W.toggle = toggle; W.seekBy = seekBy;
  v.onplay = v.onpause = () => { pl.classList.toggle("paused", v.paused); $("#pp").innerHTML = ic(v.paused ? "play" : "pause"); if ("mediaSession" in navigator) navigator.mediaSession.playbackState = v.paused ? "paused" : "playing"; };
  v.onwaiting = v.onloadstart = v.onseeking = () => bz(true);
  v.onplaying = v.oncanplay = v.onseeked = () => bz(false);
  v.onended = () => { if (store("yn_ap", true)) playNext(); };
  $("#pp").onclick = toggle; $("#nx").onclick = playNext;
  $("#mu").onclick = () => { v.muted = !v.muted; $("#mu").innerHTML = ic(v.muted ? "mute" : "vol"); };
  $("#vol").oninput = e => { v.volume = e.target.value; v.muted = false; $("#mu").innerHTML = ic(v.volume ? "vol" : "mute"); };
  $("#ap").onclick = e => { const on = !store("yn_ap", true); save("yn_ap", on); e.currentTarget.classList.toggle("on", on); };
  $("#mm").onclick = () => setMusic(!W.music);
  $("#fs").onclick = toggleFs;
  W.fsh = fsSync; document.addEventListener("fullscreenchange", W.fsh);
  const mn = $("#mn");
  const root = () => { mn.innerHTML = `<button class="mi" data-a="speed">${ic("play")}<span>${t("speed")}</span><em>${v.playbackRate === 1 ? t("normal") : v.playbackRate + "x"}</em></button><button class="mi" data-a="pip">${ic("pip")}<span>${t("pip")}</span></button><button class="mi" data-a="pop">${ic("pop")}<span>${t("popup")}</span></button>`; };
  const spd = () => { mn.innerHTML = `<button class="mi back" data-a="root">${ic("back")}<span>${t("speed")}</span></button>` + SPEEDS.map(s => `<button class="mi" data-s="${s}">${v.playbackRate === s ? ic("check") : "<i></i>"}<span>${s === 1 ? t("normal") : s}</span></button>`).join(""); };
  $("#st").onclick = e => { e.stopPropagation(); if (mn.hidden) { root(); mn.hidden = false; } else mn.hidden = true; };
  mn.onclick = e => {
    e.stopPropagation(); const b = e.target.closest(".mi"); if (!b) return;
    if (b.dataset.s) { v.playbackRate = +b.dataset.s; mn.hidden = true; return; }
    const a = b.dataset.a;
    if (a === "speed") spd(); else if (a === "root") root();
    else if (a === "pip") { mn.hidden = true; document.pictureInPictureElement ? document.exitPictureInPicture() : v.requestPictureInPicture?.(); }
    else if (a === "pop") { mn.hidden = true; v.pause(); window.open(`/watch?v=${W.id}&popup=1`, "ytp", "popup,width=640,height=380"); }
  };
  pl.addEventListener("click", e => {
    if (e.target.closest(".ctl,.mn")) return;
    if (!mn.hidden) { mn.hidden = true; return; }
    if (e.pointerType === "touch" && pl.classList.contains("idle")) { wake(); return; }
    if (ck) { clearTimeout(ck); ck = null; const r = pl.getBoundingClientRect(), x = (e.clientX - r.left) / r.width; if (x < .33) seekBy(-10); else if (x > .67) seekBy(10); else toggleFs(); return; }
    ck = setTimeout(() => { ck = null; toggle(); }, 260);
  });
  const wake = () => { pl.classList.remove("idle"); clearTimeout(W.idle); W.idle = setTimeout(() => !v.paused && mn.hidden && pl.classList.add("idle"), 2800); };
  pl.onmousemove = pl.ontouchstart = pl.onpointerdown = wake; wake();
  v.onerror = () => { if (v.src && !W.retried) { W.retried = 1; const t0 = v.currentTime; v.src = v.src; v.currentTime = t0; } };
  if ($("#vid").autoplay) v.play().catch(() => { bz(false); });
}
document.addEventListener("keydown", e => {
  if (!W.v || e.ctrlKey || e.metaKey || e.altKey || /INPUT|TEXTAREA/.test(e.target.tagName) && e.target.type !== "range") return;
  const v = W.v, k = e.key.toLowerCase();
  if (k === " " || k === "k") { e.preventDefault(); W.toggle(); }
  else if (k === "arrowright") { e.preventDefault(); W.seekBy(5); } else if (k === "arrowleft") { e.preventDefault(); W.seekBy(-5); }
  else if (k === "l") W.seekBy(10); else if (k === "j") W.seekBy(-10);
  else if (k === "arrowup") { e.preventDefault(); v.volume = Math.min(1, v.volume + .05); $("#vol").value = v.volume; }
  else if (k === "arrowdown") { e.preventDefault(); v.volume = Math.max(0, v.volume - .05); $("#vol").value = v.volume; }
  else if (k === "f") toggleFs(); else if (k === "m") $("#mu").click();
  else if (k === "n" && e.shiftKey) playNext(); else if (k === "p" && e.shiftKey) playPrev();
  else if (/^[0-9]$/.test(k) && v.duration) v.currentTime = v.duration * +k / 10;
  else if (k === "," && v.paused) v.currentTime -= 1 / 30; else if (k === "." && v.paused) v.currentTime += 1 / 30;
  else if (k === "<") v.playbackRate = Math.max(.25, v.playbackRate - .25); else if (k === ">") v.playbackRate = Math.min(2, v.playbackRate + .25);
  else if (k === "escape" && W.pl.classList.contains("pfs")) toggleFs();
});
function setMS(i) {
  if (!("mediaSession" in navigator) || !W.v) return; const ms = navigator.mediaSession, v = W.v;
  ms.metadata = new MediaMetadata({title: i.title || "", artist: i.channel || "", album: "ytnetwork", artwork: [{src: `https://i.ytimg.com/vi/${i.id}/hqdefault.jpg`, sizes: "480x360", type: "image/jpeg"}]});
  const h = (a, f) => { try { ms.setActionHandler(a, f); } catch {} };
  h("play", () => v.play()); h("pause", () => v.pause());
  h("seekbackward", d => v.currentTime -= d?.seekOffset || 10); h("seekforward", d => v.currentTime += d?.seekOffset || 10);
  h("seekto", d => v.currentTime = d.seekTime); h("nexttrack", playNext); h("previoustrack", playPrev);
}
let SH = null, muted = false;
function stopShorts() { if (SH) { SH.io.disconnect(); SH.items.forEach(unmount); SH = null; } $("#sh").innerHTML = ""; document.body.style.overflow = ""; }
function openShorts() {
  show("shorts"); document.body.style.overflow = "hidden";
  SH = {items: [], page: 1, cur: -1, busy: false, seen: new Set(), tries: 0, io: new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { SH.cur = +e.target.dataset.i; sync(); } }), {root: $("#sh"), threshold: .6})};
  const sk = document.createElement("div"); sk.className = "short sks"; sk.id = "shsk";
  sk.innerHTML = `<div class="col skel"><div class="bz on"><i class="spin"></i></div><div class="ov"><i class="ln s skel"></i><i class="ln skel"></i></div></div>`;
  $("#sh").append(sk); loadShorts();
}
async function loadShorts() {
  const S = SH; if (!S || S.busy) return; S.busy = true; const n0 = S.items.length;
  try { await feed({short: 1, page: S.page, l: L, mix: mix(), q: interests().join("|")}, i => { if (SH !== S || S.seen.has(i.id)) return; S.seen.add(i.id); $("#shsk")?.remove(); addShort(i); }); } catch {}
  if (SH !== S) return; S.page++; S.busy = false; if (S.items.length === n0 && ++S.tries < 5) loadShorts(); else if (!S.items.length) $("#shsk")?.remove();
}
function addShort(i) {
  const d = document.createElement("div"); d.className = "short"; d.dataset.i = SH.items.length;
  const th = `https://i.ytimg.com/vi/${i.id}/hqdefault.jpg`;
  d.innerHTML = `<img class="bgimg" src="${th}"><div class="col"><img class="poster" src="${th}"><div class="bz on"><i class="spin"></i></div><div class="fl"></div><div class="ov"><span class="n">${avatar(i.cid, i.channel, "sm")}${esc(i.channel)}</span><span class="tt">${esc(i.title)}</span></div><div class="rail"><button class="rb lk">${ic("like")}</button><button class="rb mt">${ic(muted ? "mute" : "vol")}</button><button class="rb sh">${ic("share")}</button><button class="rb op">${ic("vid")}</button></div><div class="pb"><i></i></div></div>`;
  i.el = d;
  $(".mt", d).onclick = e => { e.stopPropagation(); muted = !muted; SH.items.forEach(x => x.v && (x.v.muted = muted)); document.querySelectorAll("#sh .mt").forEach(b => b.innerHTML = ic(muted ? "mute" : "vol")); };
  $(".lk", d).onclick = e => { e.stopPropagation(); e.currentTarget.classList.toggle("on"); };
  $(".sh", d).onclick = e => { e.stopPropagation(); const u = `${location.origin}/watch?v=${i.id}`; if (navigator.share) navigator.share({title: i.title, url: u}).catch(() => {}); else navigator.clipboard?.writeText(u); };
  $(".op", d).onclick = e => { e.stopPropagation(); nav(`/watch?v=${i.id}`, i); };
  $(".col", d).onclick = e => { if (e.target.closest(".rail")) return; const v = i.v; if (!v) return; const f = $(".fl", d); if (v.paused) { v.play(); f.innerHTML = ic("play"); } else { v.pause(); f.innerHTML = ic("pause"); } f.classList.remove("go"); void f.offsetWidth; f.classList.add("go"); };
  SH.items.push(i); SH.io.observe(d); $("#sh").append(d);
}
function mount(i, cur, next) {
  if (!i.v) {
    const v = i.v = document.createElement("video"), bz = $(".bz", i.el);
    v.src = `/stream/${i.id}`; v.loop = true; v.playsInline = true; v.muted = muted; v.setAttribute("webkit-playsinline", "");
    v.ontimeupdate = () => v.duration && ($(".pb i", i.el).style.width = v.currentTime / v.duration * 100 + "%");
    v.onwaiting = v.onloadstart = v.onseeking = () => bz.classList.add("on");
    v.onplaying = () => { bz.classList.remove("on"); i.el.classList.add("ready"); };
    v.oncanplay = () => { if (!v.paused) bz.classList.remove("on"); };
    $(".col", i.el).prepend(v);
  }
  i.v.preload = cur || next ? "auto" : "metadata";
  if (cur) i.v.play().catch(() => { muted = true; i.v.muted = true; i.v.play().catch(() => {}); });
  else i.v.pause();
}
function unmount(i) { if (i.v) { i.v.pause(); i.v.removeAttribute("src"); i.v.load(); i.v.remove(); i.v = null; i.el?.classList.remove("ready"); $(".bz", i.el)?.classList.add("on"); } }
function sync() { const c = SH.cur; SH.items.forEach((i, n) => Math.abs(n - c) <= 1 ? mount(i, n === c, n === c + 1) : unmount(i)); if (c >= SH.items.length - 3) loadShorts(); }
const shGo = d => SH?.items[SH.cur + d]?.el.scrollIntoView({behavior: "smooth"});
document.addEventListener("keydown", e => { if (!SH) return; const d = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0; if (d) { e.preventDefault(); shGo(d); } });
$("#su").onclick = () => shGo(-1); $("#sd").onclick = () => shGo(1);
$("#sx").onclick = () => nav("/");
function closeSide() { $("#side").classList.remove("open"); $("#scrim").classList.remove("on"); }
const searchNav = q => nav(`/results?search_query=${encodeURIComponent(q)}`);
function renderSide(v) {
  const items = [["home", "home", () => nav("/")], ["shorts", "shorts", () => nav("/shorts")], ["music", "music", () => searchNav(t("music"))]];
  const on = v === "home" ? "home" : v === "shorts" ? "shorts" : "";
  const sb = Object.entries(subs);
  $("#side").innerHTML = items.map(([k, i]) => `<button class="si ${on === k ? "on" : ""}" data-k="${k}">${ic(i)}<span>${t(k)}</span></button>`).join("") + (sb.length ? `<div class="sh3">${t("subscriptions")}</div>` + sb.map(([n, cid]) => `<button class="si" data-ch="${esc(n)}">${avatar(cid === 1 ? null : cid, n, "sm")}<span>${esc(n)}</span></button>`).join("") : "");
  $("#bnav").innerHTML = items.map(([k, i]) => `<button class="${on === k ? "on" : ""}" data-k="${k}">${ic(i)}<span>${t(k)}</span></button>`).join("");
}
const sideClick = e => { const b = e.target.closest("button"); if (!b) return; if (b.dataset.k) items0[b.dataset.k](); else if (b.dataset.ch) searchNav(b.dataset.ch); closeSide(); };
const items0 = {home: () => nav("/"), shorts: () => nav("/shorts"), music: () => searchNav(t("music"))};
$("#side").onclick = sideClick; $("#bnav").onclick = sideClick;
$("#scrim").onclick = closeSide;
$("#menu").onclick = () => {
  const wide = innerWidth >= 1100 && /v-(home|results)/.test(document.body.className);
  if (wide) document.body.classList.toggle("side-off");
  else { const o = $("#side").classList.toggle("open"); $("#scrim").classList.toggle("on", o); }
};
$("#q").placeholder = t("search"); $("#sb").setAttribute("aria-label", t("search"));
$("#sf").onsubmit = e => { e.preventDefault(); const q = $("#q").value.trim(); if (q) { $("#q").blur(); searchNav(q); } };
$("#logo").onclick = e => { e.preventDefault(); nav("/"); };
route();
})();
