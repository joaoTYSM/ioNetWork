import glob, hashlib, json, os, re, shutil, tempfile, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from flask import Flask, Response, abort, jsonify, redirect, request, send_file, send_from_directory
from yt_dlp import YoutubeDL

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(HERE, "static")
app = Flask(__name__, static_folder=STATIC, static_url_path="/static")
S = requests.Session()
S.mount("https://", requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=60))
lock, locks, cache = threading.Lock(), {}, {}
pool = ThreadPoolExecutor(12)

JSR = {r: {} for r in ("deno", "node", "bun") if shutil.which(r)}
BASE = {"quiet": True, "no_warnings": True, "noplaylist": True, "socket_timeout": 15}
if JSR:
    BASE["js_runtimes"] = JSR
    BASE["remote_components"] = ["ejs:github"]

FMT = "best[ext=mp4][acodec!=none][vcodec!=none]/best[acodec!=none][vcodec!=none]/best"
AFMT = "bestaudio[ext=m4a]/bestaudio/best"

DEFAULTS = {
    "pt": ["em alta hoje", "melhores momentos", "música brasileira", "tecnologia"],
    "en": ["trending today", "best moments", "music", "technology"],
    "es": ["tendencias hoy", "mejores momentos", "música latina", "tecnología"],
    "fr": ["tendances aujourd'hui", "meilleurs moments", "musique française", "technologie"],
    "de": ["trends heute", "beste momente", "deutsche musik", "technik"],
    "it": ["tendenze oggi", "momenti migliori", "musica italiana", "tecnologia"],
    "ja": ["人気 急上昇", "音楽", "ゲーム実況", "ニュース"],
    "ko": ["인기 급상승", "음악", "게임", "뉴스"],
    "ru": ["тренды сегодня", "музыка", "игры", "новости"],
    "hi": ["ट्रेंडिंग", "गाने", "मनोरंजन", "समाचार"],
    "ar": ["الأكثر رواجا", "موسيقى", "ألعاب", "أخبار"],
}
STOP = {
    "pt": "o a os as um uma de do da dos das em no na nos nas que não com para por mais como mas foi são ao você vocês isso esse essa muito também até quando eu meu minha".split(),
    "en": "the and of to in is you that it for on with this are was be as at your how what from my we they not but have".split(),
    "es": "el la los las un una de del en que y con para por más como pero fue son al tú usted esto este esta muy también hasta cuando yo mi mis".split(),
    "fr": "le la les un une des du de en et que qui pour pas avec sur dans est sont au aux ce cette très aussi mais je mon ma".split(),
    "de": "der die das und ein eine ist nicht mit für auf von zu den dem des sich auch wie aber ich du wir sie es im".split(),
    "it": "il lo la le gli un una di del della in che e per non con su come più ma è sono al questo questa molto anche io mio".split(),
}
STOP = {k: set(v) for k, v in STOP.items()}
SCRIPTS = [(r"[\u3040-\u30ff]", "ja"), (r"[\uac00-\ud7af]", "ko"), (r"[\u0400-\u04ff]", "ru"),
           (r"[\u0900-\u097f]", "hi"), (r"[\u0600-\u06ff]", "ar")]


def lang_of(t):
    t = t or ""
    for rg, l in SCRIPTS:
        if re.search(rg, t):
            return l
    if re.search(r"[ãõ]", t.lower()):
        return "pt"
    if "ñ" in t.lower():
        return "es"
    w = set(re.findall(r"[a-zà-ÿ']+", t.lower()))
    best, top, tie = None, 0, False
    for l, s in STOP.items():
        n = len(w & s)
        if n > top:
            best, top, tie = l, n, False
        elif n == top and n:
            tie = True
    return None if tie else best


def resolve(vid, audio=False):
    key = vid + ("#a" if audio else "")
    c = cache.get(key)
    if c and c["exp"] > time.time():
        return c
    with lock:
        l = locks.setdefault(key, threading.Lock())
    with l:
        c = cache.get(key)
        if c and c["exp"] > time.time():
            return c
        with YoutubeDL({**BASE, "format": AFMT if audio else FMT, "skip_download": True}) as y:
            info = y.extract_info("https://youtu.be/" + vid, download=False)
        url = info.get("url") or info["requested_formats"][0]["url"]
        c = {"url": url, "h": info.get("http_headers", {}), "exp": time.time() + 3 * 3600,
             "title": info.get("title", ""), "channel": info.get("uploader", ""),
             "cid": info.get("channel_id"), "views": info.get("view_count"),
             "likes": info.get("like_count"), "date": info.get("upload_date"),
             "desc": (info.get("description") or "")[:5000],
             "tags": [t for t in (info.get("tags") or []) if " " not in t][:3],
             "subs": info.get("channel_follower_count"), "dur": info.get("duration"),
             "lang": lang_of(info.get("title", "")),
             "chapters": [{"start": x.get("start_time", 0), "title": x.get("title", "")} for x in (info.get("chapters") or [])],
             "comment_count": info.get("comment_count"), "verified": bool(info.get("channel_is_verified"))}
        cache[key] = c
        return c


sc = {}


def ysearch(q, n):
    k = (q, n)
    c = sc.get(k)
    if c and c[0] > time.time():
        return c[1]
    with YoutubeDL({**BASE, "extract_flat": True, "skip_download": True}) as y:
        r = y.extract_info(f"ytsearch{n}:{q}", download=False)
    items = [{"id": e["id"], "title": e.get("title"), "channel": e.get("channel") or e.get("uploader"),
              "cid": e.get("channel_id"), "dur": e.get("duration"), "views": e.get("view_count"),
              "lang": lang_of(e.get("title")),
              "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg"}
             for e in r.get("entries", []) if e and len(e.get("id", "")) == 11]
    sc[k] = (time.time() + 900, items)
    return items


def allowed(i, L, mix):
    if L == "a" or i["lang"] in (None, L):
        return True
    return mix > 0 and int(hashlib.md5(i["id"].encode()).hexdigest()[:2], 16) % 100 < mix * 100


@app.route("/api/feed")
def api_feed():
    L = request.args.get("l", "en")
    qs = [x for x in request.args.get("q", "").split("|") if x.strip()][:4]
    if not qs:
        qs = DEFAULTS.get(L, DEFAULTS["en"])[:2]
    p = max(1, int(request.args.get("page", 1)))
    short = request.args.get("short") == "1"
    mix = min(0.5, float(request.args.get("mix", 0) or 0))
    per = 12 if len(qs) > 1 else 24

    def job(q):
        try:
            if short:
                items = ysearch(q + " #shorts", 30 * p)[30 * (p - 1):]
                items = [i for i in items if i["dur"] and i["dur"] <= 61]
            else:
                items = ysearch(q, per * p)[per * (p - 1):]
            return [i for i in items if allowed(i, L, mix)]
        except Exception:
            return []

    futs = [pool.submit(job, q) for q in qs]

    def gen():
        seen = set()
        for f in as_completed(futs):
            for i in f.result():
                if i["id"] not in seen:
                    seen.add(i["id"])
                    yield json.dumps(i) + "\n"

    return Response(gen(), mimetype="application/x-ndjson",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-store"})


@app.route("/api/info/<vid>")
def api_info(vid):
    try:
        c = resolve(vid)
    except Exception as e:
        return str(e), 502
    return jsonify({k: c[k] for k in ("title", "channel", "cid", "views", "likes", "date", "desc",
                                      "tags", "subs", "dur", "lang", "chapters", "comment_count", "verified")})


cc = {}


@app.route("/api/comments/<vid>")
def api_comments(vid):
    sort = "new" if request.args.get("sort") == "new" else "top"
    try:
        n = min(100, max(10, int(request.args.get("n", 20))))
    except ValueError:
        n = 20
    k = (vid, sort, n)
    c = cc.get(k)
    if c and c[0] > time.time():
        return jsonify(c[1])
    out = {"count": None, "items": []}
    ttl = 60
    try:
        opts = {**BASE, "skip_download": True, "getcomments": True,
                "extractor_args": {"youtube": {"max_comments": [str(n * 3), str(n), str(n * 2), "3", "1"],
                                               "comment_sort": [sort]}}}
        with YoutubeDL(opts) as y:
            info = y.extract_info("https://youtu.be/" + vid, download=False)
        rows = info.get("comments") or []
        by = {}
        for x in rows:
            if x.get("parent") in (None, "root"):
                by[x["id"]] = {"id": x["id"], "author": x.get("author"), "text": x.get("text"),
                               "likes": x.get("like_count"), "ts": x.get("timestamp"),
                               "thumb": x.get("author_thumbnail"), "pinned": bool(x.get("is_pinned")),
                               "creator": bool(x.get("author_is_uploader")), "heart": bool(x.get("is_favorited")),
                               "replies": []}
        for x in rows:
            p = by.get(x.get("parent"))
            if p is not None:
                p["replies"].append({"id": x["id"], "author": x.get("author"), "text": x.get("text"),
                                     "likes": x.get("like_count"), "ts": x.get("timestamp"),
                                     "thumb": x.get("author_thumbnail"), "creator": bool(x.get("author_is_uploader")),
                                     "heart": bool(x.get("is_favorited")), "pinned": False})
        out = {"count": info.get("comment_count"), "items": list(by.values())}
        ttl = 3600 if out["items"] else 60
    except Exception:
        pass
    cc[k] = (time.time() + ttl, out)
    return jsonify(out)


AV_FILE = os.path.join(HERE, "avatars.json")
try:
    av = json.load(open(AV_FILE))
except Exception:
    av = {}
av_sem = threading.Semaphore(4)


def fetch_avatar(cid):
    try:
        with YoutubeDL({**BASE, "extract_flat": True, "playlistend": 1, "skip_download": True}) as y:
            info = y.extract_info(f"https://www.youtube.com/channel/{cid}", download=False)
        th = info.get("thumbnails") or []
        pick = next((t for t in th if "avatar" in str(t.get("id", ""))), None) or \
            next((t for t in th if t.get("width") and t.get("width") == t.get("height")), None)
        url = pick["url"] if pick else None
        if url and ("ggpht" in url or "googleusercontent" in url):
            url = re.sub(r"=s\d+.*$", "=s96-c", url)
        a = {"url": url}
    except Exception:
        a = {"url": None, "retry": time.time() + 600}
    av[cid] = a
    try:
        json.dump(av, open(AV_FILE, "w"))
    except Exception:
        pass
    return a


@app.route("/avatar/<cid>")
def avatar(cid):
    if not re.fullmatch(r"[\w-]{10,40}", cid):
        abort(404)
    a = av.get(cid)
    if not a or (not a.get("url") and a.get("retry", 0) < time.time()):
        with av_sem:
            a = av.get(cid) if (av.get(cid) or {}).get("url") else fetch_avatar(cid)
    if not a.get("url"):
        abort(404)
    r = redirect(a["url"], 302)
    r.headers["Cache-Control"] = "public, max-age=86400"
    return r


@app.route("/stream/<vid>")
def stream(vid):
    audio = request.args.get("a") == "1"
    for attempt in (0, 1):
        try:
            c = resolve(vid, audio)
        except Exception as e:
            return str(e), 502
        h = dict(c["h"])
        h["Range"] = request.headers.get("Range", "bytes=0-")
        try:
            r = S.get(c["url"], headers=h, stream=True, timeout=15)
        except Exception:
            r = None
        if r is not None and r.status_code < 400:
            break
        cache.pop(vid + ("#a" if audio else ""), None)
    else:
        abort(502)
    out = {k: r.headers[k] for k in ("Content-Type", "Content-Length", "Content-Range") if k in r.headers}
    out["Accept-Ranges"] = "bytes"

    def gen():
        try:
            for chunk in r.iter_content(256 * 1024):
                yield chunk
        finally:
            r.close()

    return Response(gen(), status=r.status_code, headers=out)


@app.route("/download/<vid>")
def download(vid):
    d = tempfile.mkdtemp()
    fmt = "bv*[height<=1080]+ba/b" if shutil.which("ffmpeg") else "b[ext=mp4]/b"
    opts = {**BASE, "format": fmt, "merge_output_format": "mp4",
            "outtmpl": d + "/%(title).80s.%(ext)s", "concurrent_fragment_downloads": 8}
    with YoutubeDL(opts) as y:
        y.download(["https://youtu.be/" + vid])
    f = glob.glob(d + "/*")[0]
    resp = send_file(f, as_attachment=True, download_name=os.path.basename(f))
    resp.call_on_close(lambda: shutil.rmtree(d, ignore_errors=True))
    return resp


def page():
    r = send_from_directory(STATIC, "index.html")
    r.headers["Cache-Control"] = "no-store"
    return r


@app.route("/")
@app.route("/watch")
@app.route("/results")
@app.route("/shorts")
def pages():
    return page()


def warm():
    langs = {"en"}
    sysl = os.environ.get("LANG", "en")[:2].lower()
    if sysl in DEFAULTS:
        langs.add(sysl)
    for l in langs:
        for q in DEFAULTS[l][:2]:
            try:
                ysearch(q, 12)
            except Exception:
                pass


if __name__ == "__main__":
    threading.Thread(target=warm, daemon=True).start()
    PORT = int(os.environ.get("PORT", 8765))
    print("JS runtime:", list(JSR) or "NONE (optional: install nodejs for fewer extraction errors)")
    print(f"ytnetwork at http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
